import os
import time
import json
import hashlib
import shutil
import subprocess
from pathlib import Path
from datetime import datetime, timedelta, timezone

import requests
from dotenv import load_dotenv

load_dotenv()

BOT = os.getenv("TELEGRAM_BOT_TOKEN", "")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
POLL = int(os.getenv("POLL_SECONDS", "30"))
CLIP_SECONDS = int(os.getenv("CLIP_SECONDS", "35"))
MIN_SCORE = float(os.getenv("MIN_SCORE", "70"))
MAX_CLIPS = int(os.getenv("MAX_CLIPS_PER_STREAM", "10"))
WORK = Path(os.getenv("WORK_DIR", "/data"))
WORK.mkdir(parents=True, exist_ok=True)
STATE = WORK / "state.json"
CHANNELS = Path("/app/config/channels.txt")

session = requests.Session()

def load_state():
    if STATE.exists():
        try:
            return json.loads(STATE.read_text())
        except Exception:
            pass
    return {"clips": {}, "streams": {}}

def save_state(s):
    STATE.write_text(json.dumps(s, indent=2))

def channels():
    if not CHANNELS.exists():
        return []
    return [x.strip().lstrip("@") for x in CHANNELS.read_text().splitlines()
            if x.strip() and not x.strip().startswith("#")]

def kick_livestreams():
    """Return live channels using Kick's public API endpoint.
    API response shapes can change, so this parser is deliberately defensive."""
    url = "https://api.kick.com/public/v1/livestreams"
    try:
        r = session.get(url, timeout=15)
        r.raise_for_status()
        payload = r.json()
        data = payload.get("data", payload if isinstance(payload, list) else [])
        return data
    except Exception as e:
        print("Kick API:", e)
        return []

def channel_is_live(name, live_items):
    name = name.lower()
    for item in live_items:
        for key in ("slug", "channel_slug", "username", "user_name", "channel"):
            v = item.get(key)
            if isinstance(v, dict):
                v = v.get("slug") or v.get("username")
            if isinstance(v, str) and v.lower() == name:
                return item
    return None

def stream_url(channel):
    return f"https://kick.com/{channel}"

def start_capture(channel, outdir):
    outdir.mkdir(parents=True, exist_ok=True)
    out = outdir / "stream.%(ext)s"
    cmd = [
        "yt-dlp", "--no-part", "--live-from-start", "--hls-use-mpegts",
        "-o", str(out), stream_url(channel)
    ]
    print("Starting capture:", channel)
    return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)

def extract_candidates(stream_file, outdir):
    """Create overlapping candidate clips from the captured media."""
    clips = []
    try:
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(stream_file)],
            capture_output=True, text=True, timeout=30
        )
        duration = float(probe.stdout.strip())
    except Exception:
        return clips

    if duration < CLIP_SECONDS:
        return clips

    # Inspect recent material only; this keeps the loop cheap.
    start = max(0, duration - CLIP_SECONDS * 4)
    for i, offset in enumerate([start, start + CLIP_SECONDS, start + 2*CLIP_SECONDS]):
        if offset + CLIP_SECONDS > duration:
            continue
        candidate = outdir / f"candidate_{int(offset)}.mp4"
        subprocess.run([
            "ffmpeg", "-y", "-ss", str(offset), "-i", str(stream_file),
            "-t", str(CLIP_SECONDS), "-c:v", "libx264", "-preset", "veryfast",
            "-c:a", "aac", "-movflags", "+faststart", str(candidate)
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=180)
        if candidate.exists():
            clips.append(candidate)
    return clips

def score_clip(path):
    """Cheap first-pass scoring.

    Uses audio RMS/peak and scene-change count. This is not an AI claim of virality;
    it is a candidate filter that can later be replaced with Whisper/LLM scoring.
    """
    score = 40.0

    # Audio activity
    try:
        p = subprocess.run([
            "ffmpeg", "-i", str(path), "-af", "volumedetect",
            "-f", "null", "-"
        ], capture_output=True, text=True, timeout=90)
        text = p.stderr
        mean = None
        peak = None
        for line in text.splitlines():
            if "mean_volume:" in line:
                mean = float(line.split("mean_volume:")[1].split(" dB")[0])
            if "max_volume:" in line:
                peak = float(line.split("max_volume:")[1].split(" dB")[0])
        if mean is not None:
            score += max(0, min(20, (mean + 35) * 0.9))
        if peak is not None and peak > -3:
            score += 10
    except Exception:
        pass

    # Scene changes / visual activity
    try:
        p = subprocess.run([
            "ffmpeg", "-i", str(path),
            "-vf", "select='gt(scene,0.35)',metadata=print",
            "-an", "-f", "null", "-"
        ], capture_output=True, text=True, timeout=90)
        changes = p.stderr.count("lavfi.scene_score")
        score += min(20, changes * 2)
    except Exception:
        pass

    return round(min(100, score), 1)

def make_social_clip(src, dst, title):
    # Vertical 9:16 layout: scale to fill and crop, then add readable title.
    vf = (
        "scale=1080:1920:force_original_aspect_ratio=increase,"
        "crop=1080:1920,"
        "setsar=1,"
        f"drawtext=text='{title.replace(chr(39), '')}':"
        "x=(w-text_w)/2:y=90:fontsize=54:"
        "fontcolor=white:borderw=4:bordercolor=black"
    )
    subprocess.run([
        "ffmpeg", "-y", "-i", str(src), "-vf", vf,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "22",
        "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(dst)
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=240)

def telegram_send(path, caption):
    if not BOT or not CHAT_ID:
        print("Telegram not configured:", path)
        return False
    try:
        with path.open("rb") as f:
            r = requests.post(
                f"https://api.telegram.org/bot{BOT}/sendVideo",
                data={"chat_id": CHAT_ID, "caption": caption},
                files={"video": (path.name, f, "video/mp4")},
                timeout=180
            )
        print("Telegram:", r.status_code)
        return r.ok
    except Exception as e:
        print("Telegram error:", e)
        return False

def cleanup():
    cutoff = datetime.now(timezone.utc) - timedelta(days=int(os.getenv("KEEP_LOCAL_DAYS", "2")))
    for p in WORK.glob("**/*.mp4"):
        try:
            if datetime.fromtimestamp(p.stat().st_mtime, timezone.utc) < cutoff:
                p.unlink()
        except Exception:
            pass

def main():
    print("Vyrclip 24/7 starting...")
    state = load_state()
    processes = {}

    while True:
        try:
            live = kick_livestreams()
            wanted = channels()

            for ch in wanted:
                item = channel_is_live(ch, live)
                if item and ch not in processes:
                    folder = WORK / "streams" / ch
                    p = start_capture(ch, folder)
                    processes[ch] = (p, folder, time.time())
                    state["streams"][ch] = {"started": datetime.now(timezone.utc).isoformat()}
                    save_state(state)

            # Process captures periodically.
            for ch, (proc, folder, started) in list(processes.items()):
                if proc.poll() is not None:
                    del processes[ch]
                    continue

                media = list(folder.glob("stream.*"))
                if not media:
                    continue
                media.sort(key=lambda p: p.stat().st_mtime, reverse=True)
                stream_file = media[0]

                candidates = extract_candidates(stream_file, folder / "candidates")
                sent_this_round = 0

                for candidate in candidates:
                    if sent_this_round >= MAX_CLIPS:
                        break
                    key = hashlib.sha1(candidate.read_bytes()).hexdigest()
                    if key in state["clips"]:
                        continue

                    score = score_clip(candidate)
                    state["clips"][key] = {"score": score, "channel": ch,
                                           "time": datetime.now(timezone.utc).isoformat()}
                    save_state(state)

                    print(ch, candidate.name, "score", score)
                    if score >= MIN_SCORE:
                        out = folder / f"VYRCLIP_{int(time.time())}_{int(score)}.mp4"
                        make_social_clip(candidate, out, f"{ch} • Vyrclip")
                        caption = (
                            f"🔥 VYRCLIP\n"
                            f"Streamer: {ch}\n"
                            f"Score: {score}/100\n"
                            f"Length: {CLIP_SECONDS}s"
                        )
                        if telegram_send(out, caption):
                            sent_this_round += 1

            cleanup()
            time.sleep(POLL)

        except KeyboardInterrupt:
            break
        except Exception as e:
            print("Main loop error:", repr(e))
            time.sleep(POLL)

if __name__ == "__main__":
    main()
